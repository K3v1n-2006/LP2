﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void btnInstanciar_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();
            objMensalista.NomeEmpregago = txtNome.Text;
            objMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime (txtData.Text);
            objMensalista.SalarioMensal = Convert.ToDouble (txtSalario.Text);

            MessageBox.Show("Nome:" + objMensalista.NomeEmpregago + "\n" + "Matrícula:" + objMensalista.Matricula + "\n" + "Tempo de Trabalho:" + objMensalista.TempoTrabalho() + "\n" + "Salário Final=" + objMensalista.SalarioBruto().ToString("N2"));
        }

        private void frmMensalista_Load(object sender, EventArgs e)
        {
            
        }

        private void btnInstMensalParam_Click(object sender, EventArgs e)
        {

            Mensalista ObjMensalista = new Mensalista(Convert.ToInt32(txtMatricula.Text),
                txtNome.Text,
                Convert.ToDateTime(txtData.Text),
                Convert.ToDouble(txtSalario.Text));

            MessageBox.Show("Nome:" + ObjMensalista.NomeEmpregago + "\n" + "Matrícula:" + ObjMensalista.Matricula + "\n" + "Tempo de Trabalho:" + ObjMensalista.TempoTrabalho() + "\n" + "Salário Final=" + ObjMensalista.SalarioBruto().ToString("N2"));

    }
    }
}
