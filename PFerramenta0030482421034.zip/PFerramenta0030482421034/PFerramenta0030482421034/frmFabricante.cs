﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PFerramenta0030482421034
{
    public partial class frmFabricante : Form
    {
        private BindingSource bnFabricante = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsFabricante = new DataSet();

        public frmFabricante()
        {
            InitializeComponent();
        }


        private void btnNovoRegistro_Click(object sender, EventArgs e)
        {
            if (tbFabricante.SelectedIndex == 0)
            {
                tbFabricante.SelectTab(1);
            }

            bnFabricante.AddNew();
            txtNome.Enabled = true;
            txtNome.Focus();
            btnSalva.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovoRegistro.Enabled = false;
            btnExcluir.Enabled = false;
            btncancelar.Enabled = true;

            bInclusao = true;
        }

        private void btnSalva_Click(object sender, EventArgs e)
        {
            //Validar os dados 
            if (txtNome.Text == "" ||
                (txtNome.Text.Replace(" ", "").Length < 5))
            {
                MessageBox.Show("Fabricante inválido");
            }
            else
            {
                Fabricante RegFab = new Fabricante();
                RegFab.IdFabricante = Convert.ToInt16(txtId.Text);
                RegFab.NomeFantasia = txtNome.Text;

                if (bInclusao)
                {
                    if (RegFab.Salvar() > 0)
                    {
                        MessageBox.Show("Fabricante adicionado com sucesso");

                        btnSalva.Enabled = false;
                        txtId.Enabled = false;
                        txtNome.Enabled = false;
                        btnSalva.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovoRegistro.Enabled = true;
                        btnExcluir.Enabled = true;
                        btncancelar.Enabled = false;

                        bInclusao = false;

                        dsFabricante.Tables.Clear();
                        dsFabricante.Tables.Add(RegFab.Listar());
                        bnFabricante.DataSource = dsFabricante.Tables["FABRICANTE"];

                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Fabricante!");
                    }
                }
                else
                {

                    if (RegFab.Alterar() > 0)
                    {
                        MessageBox.Show("Fabricante alterado com sucesso!");
                        dsFabricante.Tables.Clear();
                        dsFabricante.Tables.Add(RegFab.Listar());
                        txtId.Enabled = false;
                        txtNome.Enabled = false;
                        btnSalva.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovoRegistro.Enabled = true;
                        btnExcluir.Enabled = true;
                        btncancelar.Enabled = false;
                    }
                    else
                    {
                        MessageBox.Show("Erro ao alterar fabricante!");

                    }
                }
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbFabricante.SelectedIndex == 0)
            {
                tbFabricante.SelectTab(1);
            }

            txtNome.Enabled = true;
            txtNome.Focus();
            btnSalva.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovoRegistro.Enabled = false;
            btnExcluir.Enabled = false;
            btncancelar.Enabled = true;
            bInclusao = false;
        }

        private void btncancelar_Click(object sender, EventArgs e)
        {
            bnFabricante.CancelEdit();

            txtNome.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovoRegistro.Enabled = true;
            btnSalva.Enabled = false;
            btnExcluir.Enabled = true;
            btncancelar.Enabled = false;

            bInclusao = false;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if(tbFabricante.SelectedIndex == 0)
            {
                tbFabricante.SelectTab(1);
            }

            if (MessageBox.Show("Confirma exclusão?", "Yes or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Fabricante RegFab = new Fabricante();
                RegFab.IdFabricante = Convert.ToInt16(txtId.Text);

                if (RegFab.Excluir() > 0)
                {
                    MessageBox.Show("Fabricante excluido com sucesso");

                    Fabricante R = new Fabricante();
                    dsFabricante.Tables.Clear();
                    dsFabricante.Tables.Add(R.Listar());
                    bnFabricante.DataSource = dsFabricante.Tables["FABRICANTE"];
                }
                else
                {
                    MessageBox.Show("Erro ao  excluir fabricante!");
                }
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmFabricante_Load(object sender, EventArgs e)
        {
            try
            {
                Fabricante RegCat = new Fabricante();
                dsFabricante.Tables.Add(RegCat.Listar());
                bnFabricante.DataSource = dsFabricante.Tables["Fabricante"];
                dgvFabricante.DataSource = bnFabricante;
                bnvFabricante.BindingSource = bnFabricante;

                txtId.DataBindings.Add("TEXT", bnFabricante, "id");
                txtNome.DataBindings.Add("TEXT", bnFabricante, "nomefantasia");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
