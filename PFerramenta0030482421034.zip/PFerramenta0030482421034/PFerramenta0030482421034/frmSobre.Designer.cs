﻿namespace PFerramenta0030482421034
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSobre));
            this.pxboxGato1 = new System.Windows.Forms.PictureBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblAlunos = new System.Windows.Forms.Label();
            this.lblAluno1 = new System.Windows.Forms.Label();
            this.lblAluno2 = new System.Windows.Forms.Label();
            this.rchTxtBox = new System.Windows.Forms.RichTextBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.pxboxGato2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pxboxGato1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pxboxGato2)).BeginInit();
            this.SuspendLayout();
            // 
            // pxboxGato1
            // 
            this.pxboxGato1.Image = ((System.Drawing.Image)(resources.GetObject("pxboxGato1.Image")));
            this.pxboxGato1.Location = new System.Drawing.Point(396, 135);
            this.pxboxGato1.Name = "pxboxGato1";
            this.pxboxGato1.Size = new System.Drawing.Size(233, 230);
            this.pxboxGato1.TabIndex = 0;
            this.pxboxGato1.TabStop = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblTitulo.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(37, 9);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(337, 29);
            this.lblTitulo.TabIndex = 4;
            this.lblTitulo.Text = "Trabalho do Banco de dados APOLO";
            // 
            // lblAlunos
            // 
            this.lblAlunos.AutoSize = true;
            this.lblAlunos.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblAlunos.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlunos.Location = new System.Drawing.Point(411, 20);
            this.lblAlunos.Name = "lblAlunos";
            this.lblAlunos.Size = new System.Drawing.Size(61, 15);
            this.lblAlunos.TabIndex = 5;
            this.lblAlunos.Text = "ALUNOS:";
            // 
            // lblAluno1
            // 
            this.lblAluno1.AutoSize = true;
            this.lblAluno1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblAluno1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAluno1.Location = new System.Drawing.Point(398, 70);
            this.lblAluno1.Name = "lblAluno1";
            this.lblAluno1.Size = new System.Drawing.Size(233, 21);
            this.lblAluno1.TabIndex = 6;
            this.lblAluno1.Text = "Kevin Gabriel Gaspar Ferreira";
            // 
            // lblAluno2
            // 
            this.lblAluno2.AutoSize = true;
            this.lblAluno2.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblAluno2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAluno2.Location = new System.Drawing.Point(398, 111);
            this.lblAluno2.Name = "lblAluno2";
            this.lblAluno2.Size = new System.Drawing.Size(231, 21);
            this.lblAluno2.TabIndex = 7;
            this.lblAluno2.Text = "Juan Pablo Camargo Da Silva";
            // 
            // rchTxtBox
            // 
            this.rchTxtBox.Enabled = false;
            this.rchTxtBox.Location = new System.Drawing.Point(12, 58);
            this.rchTxtBox.Name = "rchTxtBox";
            this.rchTxtBox.Size = new System.Drawing.Size(362, 162);
            this.rchTxtBox.TabIndex = 9;
            this.rchTxtBox.Text = "";
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(714, 392);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 23);
            this.btnSair.TabIndex = 11;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // pxboxGato2
            // 
            this.pxboxGato2.Image = ((System.Drawing.Image)(resources.GetObject("pxboxGato2.Image")));
            this.pxboxGato2.Location = new System.Drawing.Point(12, 226);
            this.pxboxGato2.Name = "pxboxGato2";
            this.pxboxGato2.Size = new System.Drawing.Size(208, 189);
            this.pxboxGato2.TabIndex = 12;
            this.pxboxGato2.TabStop = false;
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1178, 644);
            this.Controls.Add(this.pxboxGato2);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.rchTxtBox);
            this.Controls.Add(this.lblAluno2);
            this.Controls.Add(this.lblAluno1);
            this.Controls.Add(this.lblAlunos);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.pxboxGato1);
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            this.Load += new System.EventHandler(this.frmSobre_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pxboxGato1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pxboxGato2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pxboxGato1;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblAlunos;
        private System.Windows.Forms.Label lblAluno1;
        private System.Windows.Forms.Label lblAluno2;
        private System.Windows.Forms.RichTextBox rchTxtBox;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.PictureBox pxboxGato2;
    }
}