﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PFerramenta0030482421034
{
    public partial class frmSobre : Form
    {
        public frmSobre()
        {
            InitializeComponent();
        }

        private void frmSobre_Load(object sender, EventArgs e)
        {
            
            rchTxtBox.Text = "O trabalho se trata de uma gestão dos informações usando um banco de dados nomeado 'APOLO', usando os topicos de Categoria, Ferramenta e Fabricante onde cada um mostra" +
                " seus topicos e assim na ferramenta juntando as informações dos dois forms distintos, sendo eles a categoria e o fabricante. Fazendo assim na Ferramenta ter as duas informações ";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
