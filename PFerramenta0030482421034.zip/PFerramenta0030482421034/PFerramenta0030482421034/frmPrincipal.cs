﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;


namespace PFerramenta0030482421034
{
    public partial class frmPrincipal : Form
    {

        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=APOLO;Initial Catalog=LP2;Persist Security Info=True;User ID=BD2421034;Password=K3V0LSK123460k");
                conexao.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro" + ex.Message);
            }

        }

        private void categoriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmCategoria>().Count() > 0)
            {
                Application.OpenForms["frmCategoria"].BringToFront();
            }
            else
            {
                frmCategoria FrmCategoria = new frmCategoria();
                FrmCategoria.MdiParent = this;
                FrmCategoria.WindowState = FormWindowState.Maximized;
                FrmCategoria.Show();
            }
        }

        private void fabricanteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmFabricante>().Count() > 0)
            {
                Application.OpenForms["frmFabricante"].BringToFront();
            }
            else
            {
                frmFabricante FrmFabricante = new frmFabricante();
                FrmFabricante.MdiParent = this;
                FrmFabricante.WindowState = FormWindowState.Maximized;
                FrmFabricante.Show();
            }
        }

        private void ferramentaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmFerramenta>().Count() > 0)
            {
                Application.OpenForms["frmFerramenta"].BringToFront();
            }
            else
            {
                frmFerramenta frmFerramenta = new frmFerramenta();
                frmFerramenta.MdiParent = this;
                frmFerramenta.WindowState = FormWindowState.Maximized;
                frmFerramenta.Show();
            }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmSobre>().Count() > 0)
            {
                Application.OpenForms["frmSobre"].BringToFront();
            }
            else
            {
                frmSobre frmSobre = new frmSobre();
                frmSobre.MdiParent = this;
                frmSobre.WindowState = FormWindowState.Maximized;
                frmSobre.Show();
               
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
